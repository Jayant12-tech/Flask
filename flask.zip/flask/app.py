from flask import Flask , render_template,request,session,redirect,flash
from datetime import datetime
from werkzeug import secure_filename		
from flask_mail import Mail
import smtplib
import os #this is for uploading files
from flask_sqlalchemy import SQLAlchemy
import math
app= Flask(__name__)
app.secret_key = 'the random string'
# app.config['UPLOAD_FOLDER']='C:\\Users\\jayan\\OneDrive\\Desktop\\flask\\static\\img'
app.config.update(
	MAIL_SERVER='smtp.gmail.com',
	MAIL_PORT='465',
	MAIL_USER_SSL=True,
	MAIL_USERNAME="jayantchoraria4@gmail.com",
	MAIL_PASSWORD='qwerty1234567890'
)
mail=Mail(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost:3308/flask'
db = SQLAlchemy(app)
class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80),nullable=False)
    email = db.Column(db.String(120),nullable=False)
    phone = db.Column(db.String(12),nullable=False)
    message=db.Column(db.String(120),nullable=False)

class Posts(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(80),nullable=False)
    content = db.Column(db.String(120),nullable=False)
    slug = db.Column(db.String(12),nullable=False)
    date=db.Column(db.String(120),nullable=False)
    sub_head=db.Column(db.String(120),nullable=False)
    image=db.Column(db.String(120),nullable=False)

class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(80),nullable=False)
    password = db.Column(db.String(120),nullable=False)
    name = db.Column(db.String(120),nullable=False)
   


  

@app.route('/',methods=['GET'])
def hello():

	post_db=Posts.query.filter_by().all()
	last=int(math.ceil(len(post_db)/int(2)))
	#[0:2]
	page=request.args.get('page')
	if(not str(page).isnumeric()):
		page=1
	page=int(page)
	post=post_db[(page-1)*int(2):(page-1)*int(2)+int(2)]
	if(page==1):
		prev="#"
		nex="/?page="+str(page+1)
	elif(page==last):
		prev="/?page="+str(page-1)
		nex="#"
	else:
		prev="/?page="+str(page-1)
		nex="/?page="+str(page+1)
	return render_template('index.html',post=post,prev=prev,next=nex)

@app.route('/about')
def about():
	return render_template('about.html')

@app.route('/delete/<string:id>',methods=['GET','POST'])
def delete(id):
		post=Posts.query.filter_by(id=id).first()
		db.session.delete(post)
		db.session.commit()
		return redirect('/dashboard')

@app.route('/dashboard',methods=['GET','POST'])
def dash():
	admin=Admin.query.filter_by().first()
	if ('user' in session and session['user']==admin.name):
		posts=Posts.query.filter_by().all()
		return render_template('admin.html',post=posts)
	if request.method=="POST":	
		admin=Admin.query.filter_by().first()
		if (admin.email==request.form.get('email') and admin.password==request.form.get('password')):
			session['user']=admin.name
			admins=Admin.query.filter_by().first()
			posts=Posts.query.filter_by().all()
			return render_template('admin.html',post=posts,Admin=admins)
		else:
			return render_template('login.html')	

	else:	
		return render_template('login.html')

@app.route('/contact',methods=['GET','POST'])
def contact():
	if request.method=='POST':
		#add entry to db
		name=request.form.get('name')
		phone=request.form.get('phone');
		email=request.form.get('email');
		message=request.form.get('message');
		entry=Contact(name=name,phone=phone,email=email,message=message)
		db.session.add(entry)	
		db.session.commit()
		flash("Thans For Submitting your details.We will get back to you soon!","success")
		# mail.send_message('New Message From '+ name,recipients='jayantchoraria4@gmail.com',body=message + '\n' + phone)
	return render_template('contact.html')
@app.route('/post/<string:post_slug>',methods=['GET'])
def post(post_slug):
	post_db=Posts.query.filter_by(slug=post_slug).first()
	return render_template('post.html',post=post_db)
@app.route('/logout')
def logout():
	session.pop('user')
	return redirect('/dashboard')

@app.route('/newpost',methods=['GET','POST'])
def newpost():
	if request.method=="POST":
		title=request.form.get('title')
		sub_head=request.form.get('sub')
		slug=request.form.get('slug')
		content=request.form.get('content')
		# image=request.form.get('image')
		image='ok'
		date=datetime.now()
		post=Posts(title=title,sub_head=sub_head,slug=slug,content=content,image=image,date=date)
		db.session.add(post)	
		db.session.commit()
		return redirect('/dashboard')
	return render_template('new_post.html')

@app.route('/edit/<string:id>',methods=['GET','POST'])
def edit(id):
	if ('user' in session and session['user']=='admin'):
		if request.method=="POST":
			title=request.form.get('title')
			sub_head=request.form.get('sub')
			slug=request.form.get('slug')
			content=request.form.get('content')
			# image=request.form.get('image')
			image='ok'
			date=datetime.now()
			if id=='0':
				post=Posts(title=title,sub_head=sub_head,slug=slug,content=content,image=image,date=date)
				db.session.add(post)	
				db.session.commit()
			else:
				post_db=Posts.query.filter_by(id=id).first()
				post_db.title=title
				post_db.sub_head=sub_head
				post_db.slug=slug
				post_db.content=content
				post_db.date=date
				post_db.image=image
				db.session.commit()
				return redirect('/edit/'+id)
		post_db=Posts.query.filter_by(id=id).first()
		return render_template('edit.html',post=post_db)

	# return render_template('edit.html',post=post_db)

if __name__=="__main__":
	app.run(debug=True)