{% extends "layout.html" %}
{% block body %} 
  <!-- Page Header -->
  <header class="masthead" style="background-image: url(' {{url_for('static', filename='img/home-bg.jpg')}}  ')">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          <div class="site-heading">
            <h1>Edit</h1>
            <span class="subheading">Welcome to dashboard</span>
          </div>
        </div>
      </div>
    </div>
  </header>

<div class=" container text-center">
  <div class="row">
   <h3><a href="/dashboard"><button class="btn btn-primary" style="margin: 20px">Dashboard Home</button></a></h3>
  <h3><a href="/logout"><button class="btn btn-danger" style="margin: 20px">Logout</button></a></h3>
  </div>
  <hr>
  <h2>Add/Edit Post</h2>
   <form name="sentMessage" id="contactForm" action="/newPost" method="post" enctype="multipart/form-data" novalidate>
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Title</label>
              <input type="text" class="form-control" placeholder="Title" id="name" name="title"  value="{{post.title}}" required data-validation-required-message="Please enter your name.">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Sub_Heading</label>
              <input type="text" class="form-control" placeholder="Sub_heading" id="email" name="sub" required data-validation-required-message="Please enter your email address." value="{{post.sub_head}}">
              <p class="help-block text-danger"></p>
            </div>
          </div>
           <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Slug</label>
              <input type="text" class="form-control" placeholder="Slug" id="email" name="slug" required data-validation-required-message="Please enter your email address." value="{{post.slug}}">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <div class="control-group">
            <div class="form-group col-xs-12 floating-label-form-group controls">
              <label>Content</label>
              <textarea name="content" cols="8" rows="8" class="form-control" placeholder="content">{{post.content}}</textarea>
              <p class="help-block text-danger"></p>
            </div>
          </div>
           <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Background Image</label>
              <img src="/static/img/{{post.image}}" style="width: 200px;height: 200px">
              <input class="form-control" placeholder="image" id="email" name="image" data-validation-required-message="Please enter your email address." type="file">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <br>
          <div id="success"></div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary" id="sendMessageButton">Submit</button>
          </div>
        </form>
</div>
  <!-- Main Content -->
  
{% endblock %}


  
